package com.cacheSystem;

public interface Cache {
	void add (String key, Object value, long periodinMillisec);
	void remove( String key);
	Object get (String key);
	void clear ();
	long size ();
	

}
